# Contact Tracing Rest API
A rest API built with Spring Boot and Firebase Cloud Messaging For a Flutter mobile application.