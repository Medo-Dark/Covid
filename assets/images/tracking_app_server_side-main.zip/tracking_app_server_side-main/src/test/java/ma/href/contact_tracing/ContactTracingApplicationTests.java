package ma.href.contact_tracing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactTracingApplicationTests {

    @Test
    void contextLoads() {
    }

}
