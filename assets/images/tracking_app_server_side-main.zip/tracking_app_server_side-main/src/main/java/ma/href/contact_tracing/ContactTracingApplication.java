package ma.href.contact_tracing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ContactTracingApplication {

    public static void main(String[] args) {
        SpringApplication.run(ContactTracingApplication.class, args);
    }

}
