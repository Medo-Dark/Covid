package ma.href.contact_tracing.entities;

import lombok.Data;

import java.util.Map;

@Data
public class Notif {

    private String subject;
    private String content;
}
